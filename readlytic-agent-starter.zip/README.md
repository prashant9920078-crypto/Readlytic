# Readlytic agent

Readlytic analyses three passages a reader loves, matches their literary preferences against an Airtable book catalog, and returns a grounded **Reading Blueprint**. Every live recommendation can be sent to PRISM for evaluation.

## Architecture

```text
Bubble form -> POST /api/recommendations -> Readlytic agent
                                             |-> Airtable: approved book catalog
                                             |-> Claude: literary analysis and matching
                                             `-> PRISM: safe evaluation trace
```

## 1. Test it locally first

No packages are needed. This project uses Node's built-in HTTP server and `fetch`.

```powershell
Copy-Item .env.example .env
$env:MOCK_MODE = "true"
node server.js
```

In another terminal, test the health endpoint:

```powershell
Invoke-RestMethod http://localhost:3000/health
```

Then test the agent:

```powershell
$body = @{
  passages = @(
    "A quiet room can hold more history than a crowded city street.",
    "The rain made every window look like a small, uncertain sea.",
    "She read the letter twice, then listened to the house becoming evening."
  )
  sessionId = "readlytic-demo-1"
} | ConvertTo-Json
Invoke-RestMethod http://localhost:3000/api/recommendations -Method Post -ContentType "application/json" -Body $body
```

The initial result is a mock result. It proves the API, Bubble request format, and UI flow before paid services are involved.

Run automated checks with:

```powershell
node --test
```

## 2. Connect Airtable and Claude

1. Copy `.env.example` to `.env`.
2. Set `MOCK_MODE=false`.
3. In Airtable, create the table and view named in `.env`. Each active row needs `Title`, `Author`, `Summary`, `Genre`, `Style tags`, `Pacing`, and `Themes`.
4. Create a read-only Airtable Personal Access Token and set `AIRTABLE_PAT` and `AIRTABLE_BASE_ID`.
5. In Anthropic Console, copy an exact current model ID and set `ANTHROPIC_API_KEY` and `ANTHROPIC_MODEL`.
6. Restart `node server.js` and repeat the local API test.

## 3. Connect PRISM

1. In PRISM, complete the generic live-tracing setup and create an **ingest-only** key.
2. Put its project ID in `PRISMTRACE_PROJECT_ID` and key in `PRISMTRACE_API_KEY` in `.env`.
3. Call the recommendation endpoint once.
4. Open PRISM and verify a trace appears for `readlytic-literary-agent`.

The trace deliberately includes the model output and a short input summary, not the reader's raw literary passages.

## 4. Connect Bubble after deployment

Deploy this server to a Node-compatible host. In Bubble's API Connector create:

```text
POST https://YOUR-DEPLOYED-URL/api/recommendations
Content-Type: application/json
```

Request body:

```json
{
  "passages": ["Input Passage 1's value", "Input Passage 2's value", "Input Passage 3's value"],
  "sessionId": "Current User's unique id"
}
```

Bubble can display `blueprint` and each item from `recommendations`. Set `ALLOW_ORIGIN` to your Bubble app URL before your final demo rather than leaving it as `*`.

## PRISM before/after experiment

1. Make a baseline prompt that has no catalog-only rule.
2. Test ten fixed passage sets and record catalog validity, specificity, and hallucinated titles.
3. Use the current structured catalog-only prompt as the improved version.
4. Re-run the same ten test cases.
5. Use PRISM traces and your measured result table in the final pitch. Never fabricate the scores.
