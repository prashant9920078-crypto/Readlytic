"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const { buildPrompt, parseClaudeJson, validateRequest, demoCatalog } = require("../server");

test("accepts exactly three valid passages", () => {
  const value = validateRequest({ passages: [
    "A quiet room can hold more history than a crowded city street.",
    "The rain made every window look like a small, uncertain sea.",
    "She read the letter twice, then listened to the house becoming evening.",
  ], sessionId: "demo-session" });
  assert.equal(value.passages.length, 3);
  assert.equal(value.sessionId, "demo-session");
});

test("rejects an incomplete request", () => {
  assert.throws(() => validateRequest({ passages: ["one", "two"] }), /exactly three/);
});

test("prompt includes passages and catalog constraints", () => {
  const prompt = buildPrompt(["a".repeat(30), "b".repeat(30), "c".repeat(30)], demoCatalog);
  assert.match(prompt, /Recommend exactly three books from the supplied catalog/);
  assert.match(prompt, /Piranesi/);
});

test("extracts JSON wrapped in a markdown fence", () => {
  const result = parseClaudeJson('```json\n{"blueprint":"x","recommendations":[1,2,3]}\n```');
  assert.equal(result.recommendations.length, 3);
});
