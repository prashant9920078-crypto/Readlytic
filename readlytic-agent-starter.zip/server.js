"use strict";

const http = require("node:http");
const { randomUUID } = require("node:crypto");

const config = {
  port: Number(process.env.PORT || 3000),
  allowOrigin: process.env.ALLOW_ORIGIN || "*",
  mockMode: process.env.MOCK_MODE !== "false",
  anthropicApiKey: process.env.ANTHROPIC_API_KEY || "",
  anthropicModel: process.env.ANTHROPIC_MODEL || "",
  airtablePat: process.env.AIRTABLE_PAT || "",
  airtableBaseId: process.env.AIRTABLE_BASE_ID || "",
  airtableTable: process.env.AIRTABLE_TABLE || "Books",
  airtableView: process.env.AIRTABLE_VIEW || "MVP Catalog",
  prismHost: (process.env.PRISMTRACE_HOST || "https://prism.blockconvey.com").replace(/\/$/, ""),
  prismProjectId: process.env.PRISMTRACE_PROJECT_ID || "",
  prismApiKey: process.env.PRISMTRACE_API_KEY || "",
};

const demoCatalog = [
  {
    title: "Piranesi",
    author: "Susanna Clarke",
    genre: ["Literary fantasy"],
    styleTags: ["atmospheric", "mysterious", "lyrical"],
    pacing: "Slow burn",
    themes: ["memory", "solitude", "wonder"],
    summary: "A man records an endless, statue-filled house while slowly uncovering the truth of his own life.",
  },
  {
    title: "Klara and the Sun",
    author: "Kazuo Ishiguro",
    genre: ["Literary science fiction"],
    styleTags: ["precise", "quiet", "observant"],
    pacing: "Measured",
    themes: ["love", "consciousness", "belonging"],
    summary: "An artificial friend observes a family and asks what care and devotion really mean.",
  },
  {
    title: "The Night Circus",
    author: "Erin Morgenstern",
    genre: ["Fantasy romance"],
    styleTags: ["lush", "sensory", "dreamlike"],
    pacing: "Unhurried",
    themes: ["magic", "rivalry", "fate"],
    summary: "Two young magicians become bound to a contest staged inside an extraordinary travelling circus.",
  },
];

function sendJson(response, statusCode, data) {
  response.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": config.allowOrigin,
    "Access-Control-Allow-Methods": "POST, OPTIONS, GET",
    "Access-Control-Allow-Headers": "Content-Type",
  });
  response.end(JSON.stringify(data));
}

function readBody(request) {
  return new Promise((resolve, reject) => {
    let body = "";
    request.on("data", (chunk) => {
      body += chunk;
      if (body.length > 100_000) {
        reject(new Error("Request is too large. Keep each passage under 2,500 characters."));
        request.destroy();
      }
    });
    request.on("end", () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch {
        reject(new Error("Request body must be valid JSON."));
      }
    });
    request.on("error", reject);
  });
}

function validateRequest(payload) {
  if (!Array.isArray(payload.passages) || payload.passages.length !== 3) {
    throw new Error("Send exactly three passages in a passages array.");
  }

  const passages = payload.passages.map((passage, index) => {
    if (typeof passage !== "string") {
      throw new Error(`Passage ${index + 1} must be text.`);
    }
    const cleaned = passage.trim();
    if (cleaned.length < 20 || cleaned.length > 2_500) {
      throw new Error(`Passage ${index + 1} must be between 20 and 2,500 characters.`);
    }
    return cleaned;
  });

  return {
    passages,
    sessionId: typeof payload.sessionId === "string" && payload.sessionId.trim()
      ? payload.sessionId.trim().slice(0, 120)
      : randomUUID(),
  };
}

function normalizeBook(fields) {
  const list = (value) => Array.isArray(value) ? value : (value ? [String(value)] : []);
  return {
    title: String(fields.Title || fields.title || "").trim(),
    author: String(fields.Author || fields.author || "").trim(),
    genre: list(fields.Genre || fields.genre),
    styleTags: list(fields["Style tags"] || fields.style_tags || fields["Style Tags"]),
    pacing: String(fields.Pacing || fields.pacing || "").trim(),
    themes: list(fields.Themes || fields.themes),
    summary: String(fields.Summary || fields.summary || "").trim(),
  };
}

async function getAirtableCatalog() {
  if (!config.airtablePat || !config.airtableBaseId) {
    throw new Error("Airtable is not configured. Add AIRTABLE_PAT and AIRTABLE_BASE_ID.");
  }

  const url = new URL(`https://api.airtable.com/v0/${config.airtableBaseId}/${encodeURIComponent(config.airtableTable)}`);
  url.searchParams.set("view", config.airtableView);
  url.searchParams.set("pageSize", "100");
  const response = await fetch(url, {
    headers: { Authorization: `Bearer ${config.airtablePat}` },
  });
  if (!response.ok) {
    throw new Error(`Airtable request failed (${response.status}). Check the token, base ID, and view.`);
  }

  const data = await response.json();
  const catalog = (data.records || [])
    .map((record) => normalizeBook(record.fields || {}))
    .filter((book) => book.title && book.author && book.summary);
  if (catalog.length < 3) {
    throw new Error("Your Airtable view needs at least three complete books with Title, Author, and Summary.");
  }
  return catalog;
}

function compactCatalog(catalog) {
  return catalog.map((book) => [
    `Title: ${book.title}`,
    `Author: ${book.author}`,
    `Genre: ${book.genre.join(", ")}`,
    `Style: ${book.styleTags.join(", ")}`,
    `Pacing: ${book.pacing}`,
    `Themes: ${book.themes.join(", ")}`,
    `Summary: ${book.summary.slice(0, 500)}`,
  ].join(" | ")).join("\n");
}

function buildPrompt(passages, catalog) {
  return `<favorite_passages>
<passage index="1">${passages[0]}</passage>
<passage index="2">${passages[1]}</passage>
<passage index="3">${passages[2]}</passage>
</favorite_passages>

<catalog>
${compactCatalog(catalog)}
</catalog>

<task>
Analyse the reader's prose preferences: voice, sentence texture, pacing, emotional temperature, themes, and desired reading experience. Recommend exactly three books from the supplied catalog and no other books. Use only catalog facts; do not invent bibliographic details or quotes. Return valid JSON only, matching this schema:
{"blueprint":"90-130 word warm second-person paragraph","recommendations":[{"title":"exact catalog title","author":"exact catalog author","why":"40-70 word grounded explanation","matchTraits":["trait from passages","catalog-supported trait"]}]}
</task>`;
}

function parseClaudeJson(text) {
  const withoutFence = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  const start = withoutFence.indexOf("{");
  const end = withoutFence.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("Claude did not return the expected JSON response.");
  const result = JSON.parse(withoutFence.slice(start, end + 1));
  if (!result.blueprint || !Array.isArray(result.recommendations) || result.recommendations.length !== 3) {
    throw new Error("Claude returned an incomplete blueprint.");
  }
  return result;
}

async function callClaude(passages, catalog) {
  if (!config.anthropicApiKey || !config.anthropicModel) {
    throw new Error("Claude is not configured. Add ANTHROPIC_API_KEY and ANTHROPIC_MODEL.");
  }
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": config.anthropicApiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: config.anthropicModel,
      max_tokens: 1_000,
      system: "You are Readlytic, a careful literary critic. Ground every recommendation in the supplied catalog and respect the requested JSON schema.",
      messages: [{ role: "user", content: buildPrompt(passages, catalog) }],
    }),
  });
  if (!response.ok) {
    throw new Error(`Claude request failed (${response.status}). Check your model ID and API key.`);
  }
  const data = await response.json();
  const text = data.content?.find((block) => block.type === "text")?.text;
  if (!text) throw new Error("Claude returned no text.");
  return parseClaudeJson(text);
}

function mockBlueprint(catalog) {
  const picks = catalog.slice(0, 3);
  return {
    blueprint: "Your passages suggest that you enjoy prose that creates atmosphere before revealing its full meaning. You seem drawn to intimate observation, a thoughtful pace, and stories whose emotional questions stay with you after a chapter ends. Your next read should give you textured language and a strong inner world, while still offering a clear thread of discovery. These selections are deliberately varied in setting, but each pairs a distinctive voice with an immersive, reflective reading experience.",
    recommendations: picks.map((book) => ({
      title: book.title,
      author: book.author,
      why: `${book.title} matches your preference for ${book.styleTags.slice(0, 2).join(" and ")} writing, with a ${book.pacing.toLowerCase()} pace and themes of ${book.themes.slice(0, 2).join(" and ")}.`,
      matchTraits: [book.styleTags[0] || "atmospheric", book.themes[0] || "character-driven"],
    })),
  };
}

async function emitPrismTrace({ sessionId, output, latencyMs, catalogSize }) {
  if (!config.prismApiKey || !config.prismProjectId) return { sent: false, reason: "PRISM is not configured" };

  const response = await fetch(`${config.prismHost}/api/traces`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "X-PRISMtrace-Key": config.prismApiKey,
    },
    body: JSON.stringify({
      project_id: config.prismProjectId,
      agent_id: "readlytic-literary-agent",
      model: config.mockMode ? "readlytic-mock" : config.anthropicModel,
      // Do not send readers' raw passages to PRISM. Keep traces useful but privacy-aware.
      input_messages: [{ role: "user", content: `Readlytic request: 3 literary passages; ${catalogSize} catalog books supplied.` }],
      output_message: JSON.stringify(output),
      latency_ms: latencyMs,
      session_id: sessionId,
    }),
  });
  if (!response.ok) return { sent: false, reason: `PRISM returned ${response.status}` };
  return { sent: true };
}

async function handleRecommendation(request, response) {
  const startedAt = Date.now();
  const payload = validateRequest(await readBody(request));
  const catalog = config.mockMode ? demoCatalog : await getAirtableCatalog();
  const result = config.mockMode ? mockBlueprint(catalog) : await callClaude(payload.passages, catalog);
  const latencyMs = Date.now() - startedAt;
  const prism = await emitPrismTrace({
    sessionId: payload.sessionId,
    output: result,
    latencyMs,
    catalogSize: catalog.length,
  });

  sendJson(response, 200, {
    sessionId: payload.sessionId,
    ...result,
    meta: { mode: config.mockMode ? "mock" : "live", catalogBooks: catalog.length, latencyMs, prism },
  });
}

const server = http.createServer(async (request, response) => {
  if (request.method === "OPTIONS") return sendJson(response, 204, {});
  if (request.method === "GET" && request.url === "/health") {
    return sendJson(response, 200, { status: "ok", service: "Readlytic agent", mode: config.mockMode ? "mock" : "live" });
  }
  if (request.method === "POST" && request.url === "/api/recommendations") {
    try {
      return await handleRecommendation(request, response);
    } catch (error) {
      return sendJson(response, 400, { error: error.message || "Unable to generate recommendations." });
    }
  }
  return sendJson(response, 404, { error: "Route not found." });
});

if (require.main === module) {
  server.listen(config.port, () => console.log(`Readlytic agent listening on http://localhost:${config.port}`));
}

module.exports = { buildPrompt, parseClaudeJson, validateRequest, demoCatalog };
